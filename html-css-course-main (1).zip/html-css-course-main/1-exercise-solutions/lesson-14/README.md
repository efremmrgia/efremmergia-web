# Exercises
![exercises14-1](https://user-images.githubusercontent.com/70604577/160039662-c7d1f8de-29f6-447a-a476-449931665d9d.png)
![exercises14-2](https://user-images.githubusercontent.com/70604577/160039664-ae856eb1-fc15-4229-9a9f-f7ea3fa09c93.png)
![exercises14-3](https://user-images.githubusercontent.com/70604577/160039672-9b4235c6-9cb8-44fc-bc31-a21649af8ff5.png)
