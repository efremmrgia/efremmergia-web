# Exercises
![exercises11-1](https://user-images.githubusercontent.com/70604577/160039283-6d1d5bbd-bb5f-4a99-bacd-0816e1653b9f.png)
![exercises11-2](https://user-images.githubusercontent.com/70604577/160039286-333941fe-1f01-4476-82ef-e30a932b2c39.png)
