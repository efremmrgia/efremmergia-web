# Exercises
![exercises7-1](https://user-images.githubusercontent.com/70604577/160038742-a2b2c51f-aa3e-4836-8cf1-13edeab590c6.png)
![exercises7-2](https://user-images.githubusercontent.com/70604577/160038752-7a64f57d-4942-4694-b427-3ad7c81c65f4.png)
