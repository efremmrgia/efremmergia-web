# Exercises
https://user-images.githubusercontent.com/70604577/160038335-3f2aa74a-fd9e-484d-94b6-df88f66fc74d.mp4

https://user-images.githubusercontent.com/70604577/160038339-d2ba5ea8-9b23-4a60-977f-82cf3cbf6bca.mp4
