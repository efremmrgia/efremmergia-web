# Exercises
![Exercise 18](https://user-images.githubusercontent.com/70604577/160039866-ee41bdb7-8b71-4adc-b76b-3bb07fdd916e.png)

https://user-images.githubusercontent.com/70604577/160040128-095c8374-1f55-4afa-a99b-55a15143aad8.mp4
